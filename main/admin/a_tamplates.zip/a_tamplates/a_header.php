    <link rel="stylesheet" href="..\..\css\bootstrap.min.css">
	<script type="text/javascript" src="..\..\js\bootstrap.min.js"></script>
    <link rel="stylesheet" href="a_tamplates\a_style.css">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">Admin Dashboard</a>
    </div>
</nav>

<div class="sidebar">
    <h3>Admin Panel</h3>
    <a href="a_index.php">Manage Users</a>
    <a href="manage_songs.php">Manage Songs</a>
    <a href="manage_playlists.php">Manage Playlist</a>
    <a href="../login.php">Logout</a>
</div>